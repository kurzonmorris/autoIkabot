var MAX_374eaafc = '';
MAX_374eaafc += "<"+"div id=\'beacon_2e95ba7551\' style=\'position: absolute; left: 0px; top: 0px; visibility: hidden;\'><"+"/div>\n";
document.write(MAX_374eaafc);
