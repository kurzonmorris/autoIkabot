/*************************************************************************
* CSS here is applied to all skins (except Wikia.css) on the entire site *
* This CSS can be imported to the Wikia skin.                            *
*************************************************************************/

/***************************
* Import css pages - begin *
***************************/
 
/* @import "/load.php?mode=articles&articles=u:dev:MediaWiki:Highlight.css&only=styles"; */
@import url("/index.php?title=MediaWiki:AdminHighlights.css&action=raw&ctype=text/css");
@import url("/index.php?title=MediaWiki:Wiki_colors.css&action=raw&ctype=text/css");
@import url("/index.php?title=MediaWiki:Colors.css&action=raw&ctype=text/css");
@import url("/index.php?title=MediaWiki:Tables.css&action=raw&ctype=text/css");
@import "/load.php?mode=articles&articles=u:dev:MediaWiki:InterlanguageFlags.css&only=styles";

/*************************
* Import css pages - end *
*************************/

/******************************************************
* Hide admin, autoconfirmed, and mobile stuff - begin *
******************************************************/

.mobile-only,
.autoconfirmed-only,
.admin-only
{
  display: none;
}

/****************************************************
* Hide admin, autoconfirmed, and mobile stuff - end *
****************************************************/

/**********************************************
* Category Background & Border colors - begin *
**********************************************/

.WikiaArticleCategories
{ background: #FEB;
  border: 2px solid #DC8;
}

/********************************************
* Category Background & Border colors - end *
********************************************/

/********************
* Citations - begin *
********************/

span.citation, cite
{ font-style: normal;
  word-wrap: break-word;
}

/******************
* Citations - end *
******************/

/***************
* code - begin *
***************/

code
{ color: gray;
  background: #DC8;
}

/*************
* code - end *
*************/

/*********************************
* Documentation template - Begin *
*********************************/

.template-documentation
{ clear: both;
  margin: 1em 0 0 0;
  border: 1px solid #AAA;
  background: #EFF;
  padding: 5px;
}

.thumbinner
{ min-width: 100px;
}

/*******************************
* Documentation template - End *
*******************************/

/******************************
* External Link icons - begin *
******************************/

/* CSS */

a.external[href*=".css"]::after, a.external[href*=".CSS"]::after
{ background-image: url("https://vignette.wikia.nocookie.net/unicodesymbols/images/f/f9/CSS_mini-icon.png");
}

/* GIF */
a.external[href*=".gif"]::after, a.external[href*=".GIF"]::after
{ background-image: url("https://vignette.wikia.nocookie.net/unicodesymbols/images/8/8d/GIF_mini-icon.png");
}

/* OGG */

a.external[href*=".ogg"]::after, a.external[href*=".OGG"]::after
{ background-image: url("https://vignette.wikia.nocookie.net/unicodesymbols/images/e/e6/OGG_mini-icon.png");
}

/* PDF */

a.external[href*=".pdf"]::after, a.external[href*=".PDF"]::after
{ background-image: url("https://vignette.wikia.nocookie.net/unicodesymbols/images/f/f9/PDF_mini-icon.png");
}

/* PNG */

a.external[href*=".png"]::after, a.external[href*=".PNG"]::after
{ background-image: url("https://vignette.wikia.nocookie.net/unicodesymbols/images/b/bd/PNG_mini-icon.png");
}

/* CSS, GIF, OGG, PDF and PNG - position */

a.external[href*=".css"]::after, a.external[href*=".CSS"]::after, 
a.external[href*=".gif"]::after, a.external[href*=".GIF"]::after,
a.external[href*=".ogg"]::after, a.external[href*=".OGG"]::after, 
a.external[href*=".pdf"]::after, a.external[href*=".PDF"]::after,
a.external[href*=".png"]::after, a.external[href*=".PNG"]::after
{ background-position: left top;
  background-size: contain;
}

/* Wikipedia */

#WikiaArticle a[href*=wikipedia]:after
{ background-image: url('https://images.wikia.nocookie.net/memoryalpha/en/images/1/12/Wikipedia.png'); 
}

/****************************
* External link icons - end *
****************************/

/*******************************
* Font Characteristics - begin *
*******************************/

/* Font Sizes - begin */

.xx-small
{ font-size: xx-small;
}

.x-small
{ font-size: x-small;
}

.smaller
{ font-size: smaller;
}

.small
{ font-size: small;
}

.large
{ font-size: large;
}

.larger
{ font-size: larger;
}

.x-large
{ font-size: x-large;
}

.xx-large
{ font-size: xx-large;
}

/* Bold text */

.bold
{ font-weight: bold;
}


/* Italics */

i
{ font-style: italic;
}

/* Normal */

.normal
{ font-size: normal;
  font-style: normal;
  font-weight: normal;
  text-decoration: normal;
}

/* Capitalize */

.Capitalize, .capitalize, .CAP, .cap
{ text-transform: capitalize;
}

/* Uppercase*/

.Uppercase, .uppercase, .UC, .uc
{ text-transform: uppercase;
}

/* Lowercase*/

.Lowercase, .lowercase, .LC, .lc
{ text-transform: lowercase;
}


/*****************************
* Font Characteristics - end *
*****************************/
 
/******************
* Gallery - begin *
******************/

#content id .gallerybox div.thumb
{ background: #EEE;
}

/* Put a checkered background behind images that is only visible if they have transparency */

.gallerybox .thumb img, #file img
{ background: url( https://images.wikia.nocookie.net/__cb20080729163459/central/images/5/5d/Checker-16x16.png ) repeat;
}

/* Not on articles, user pages */

.ns-0 .gallerybox .thumb img, .ns-2 .gallerybox .thumb img, .nochecker .gallerybox .thumb img
{ background: inherent;
}

/****************
* Gallery - end *
****************/

/**************************************************
* FL, GFL and WPL template color rotation - begin *
**************************************************/

/* Template FL color rotation */
#FL
{ animation: fandomlink 3s infinite;
  -moz-animation: fandomlink 3s infinite;      /* Firefox */
  -ms-animation: fandomlink 3s infinite;       /* Internet Explorer */
  -khtml-animation: fandomlink 3s infinite;    /* Konqueror */
  -o-animation: fandomlink 3s infinite;        /* Opera */
  -webkit-animation: fandomlink 3s infinite;   /* Safari and Chrome */
}

@keyframes fandomlink
{ 0%   {color: green;}
  50%  {color: yellow;}
  100% {color: lightgreen;}
}

@-moz-keyframes fandomlink                  /* Firefox */
{ 0%   {color: green;}
  50%  {color: yellow;}
  100% {color: lightgreen;}
}

@-ms-keyframes fandomlink                   /* Internet Explorer */
{ 0%   {color: green;}
  50%  {color: yellow;}
  100% {color: lightgreen;}
}

@-khtml-keyframes fandomlink                /* Konqueror */
{ 0%   {color: green;}
  50%  {color: yellow;}
  100% {color: lightgreen;}
}

@-o-keyframes fandomlink                    /* Opera */
{ 0%   {color: green;}
  50%  {color: yellow;}
  100% {color: lightgreen;}
}

@-webkit-keyframes fandomlink                /* Chrome + Safari */
{ 0%   {color: green;}
  50%  {color: yellow;}
  100% {color: lightgreen;}
}

/* Template GFL color rotation */

#GFL
{ animation: gameforgelink 3s infinite;
  -webkit-animation: gameforgelink 3s infinite; /* Safari and Chrome */
}

@keyframes gameforgelink
{ 0%  {color: red;}
 50%  {color: orange;}
 100% {color: lightsalmon;}
}

@-webkit-keyframes gameforgelink                /* Safari and Chrome */
{ 0%  {color: red;}
 50%  {color: orange;}
 100% {color: lightsalmon;}
}

/* Template WPL color rotation */
#WPL
{ animation: wikipedialink 3s infinite;
  -webkit-animation: wikipedialink 3s infinite; /* Safari and Chrome */
}

@keyframes wikipedialink
{ 0%   {color: blue;}
  50%  {color: violet;}
  100% {color: lightblue;}
}

@-webkit-keyframes wikipedialink                /* Safari and Chrome */
{ 0%   {color: blue;}
  50%  {color: violet;}
  100% {color: lightblue;}
}

/************************************************
* FL, GFL and WPL template color rotation - end *
************************************************/

/**********************************************
* Hatnotes and disambiguation notices - begin *
**********************************************/

.dablink .hatnote, .rellink
{ font-style: italic;
}

.dablink i, .hatnote i, .rellink i
{ font-style: normal;
}

.dablink, .hatnote, .rellink, .dablink i, hatnote i, .rellink i
{ margin-left: 1em;
  margin-bottom: 1em;
}

/********************************************
* Hatnotes and disambiguation notices - end *
********************************************/

/* Italics within italics */
i i, blockquote i
{
  font-style:normal;
}

/*******************
* Headings - begin *
*******************/

/* Wiki Article Header Headings */

.page-content h1, .resizable-container h1
{ font-size: 140%;
  border-bottom: 1px solid #EEC;
  color: #666;
  font-weight: 500;
  overflow: hidden;
  text-shadow: 2px 2px 2px black;
  line-height: 30px;
  margin: .1em .1em .1em 0em;
 }
 
/* Heading 2 */

.page-content h2, .resizable-container h2
{ margin: .1em .1em .1em .1em;
}

/* Heading 3 */

.page-content h3, .resizable-container h3
{ margin: .1em .1em .1em .2em;
}

/* Heading 4 */

.page-content h4, .resizable-container h4
{ margin: .1em .1em .1em .3em;
}

/* Heading 5 */

.page-content h5, .resizable-container h5
{ margin: .1em .1em .1em .4em;
}

/* Heading 6 */

.page-content h6, .resizable-container h6
{ margin: .1em .1em .1em .5em;
}

/* New - FandomDesktop skin */

.page-content h1, .resizable-container h1, .page-content h2, .resizable-container h2, .page-content h3, .resizable-container h3,
.page-content h4, .resizable-container h4, .page-content h5, .resizable-container h5, .page-content h6, .resizable-container h6
{ font-size: 140%;
  background: #CA7;
  border-bottom: 1px solid #EEC;
  color: #EEC;
  font-weight: 500;
  overflow: hidden;
  text-shadow: 1px 1px 1px black;
  line-height: 20px;
 }

/*****************
* Headings - end *
*****************/

/***********************************
* Hlist (Horizontal lists) - begin *
***********************************/

.skin-wikia .hlist dl
{ line-height: 1.5em;
}

.hlist dl, .hlist ol, .hlist ul
{ margin: 0;
}

.hlist dd, .hlist dt, .hlist li
{ display: inline;
  margin: 0;
}

/* Display nested lists inline */

.hlist dl dl, .hlist ol ol, .hlist ul ul
{ display: inline;
}

/* Generate interpuncts */

.hlist dt:after
{ content: " :";
}

.hlist dd:after, .hlist li:after
{ content: " •";
  font-weight: bold;
}

.hlist dd:last-child:after, .hlist dt:last-child:after, .hlist li:last-child:after
{ content: none;
}

/* for IE 8 */

.hlist dd.nopunct:after, .hlist dt.nopunct:after, .hlist li.nopunct:after
{ content: none;
}

/* Add parentheses around nested lists */

.hlist dl dl:before, .hlist ol ol:before, .hlist ul ul:before
{ content: "(";
}

.hlist dl dl:after, .hlist ol ol:after, .hlist ul ul:after
{ content: ")";
}

.hlist dl dl dl:before, .hlist ol ol ol:before, .hlist ul ul ul:before
{ content: "[";
}

.hlist dl dl dl:after, .hlist ol ol ol:after, .hlist ul ul ul:after
{ content: "]";
}

/*********************************
* Hlist (Horizontal lists) - end *
*********************************/

/**************************
* Horizontal Rule - begin *
**************************/

hr
{ background: #000;
  margin: 0px 2px; 
}

/************************
* Horizontal Rule - end *
************************/

/***********************************
* ListFiles (Special Page) - begin *
***********************************/
 
.TablePager_sort
{ background-position: 2px 50%;
}

.TablePager th a
{ display: block;
} 

.TablePager_sort a
{ padding: 0 4px 0 16px;
} 

.TablePager_sort img
{ display: none;
}

/*********************************
* ListFiles (Special Page) - end *
*********************************/

/*****************
* Navbar - begin *
*****************/

.navbar
{ display: inline;
 font-size: 86%;
 font-weight: normal;
}

.navbar ul
{ display: inline;
  white-space: nowrap;
}

.navbar li
{ word-spacing: 0.125em;
}

/* Navbar styling when nested in navbox */

.navbox .navbar
{ display: block;
  font-size: 100%;
}

.navbox-title .navbar
{ float: left;
  text-align: left;
  margin-right: 0.5em;
  width: 7em;
}

/***************
* Navbar - end *
***************/

/*****************
* Nowrap - begin *
*****************/

.nowrap
{ white-space: nowrap;
}

/* prevent line breaks in links */

.nowraplinks a
{ white-space: nowrap;
}

/***************
* Nowrap - end *
***************/

/***************************
* Plainlinks tweak - begin *
***************************/

/* Remove the arrow */

.plainlinksneverexpand, .plainlinksneverexpand .urlexpansion, .plainlinksneverexpand a,
.plainlinksneverexpand a.external.text:after, .plainlinksneverexpand a.external.autonumber:after
{ background: none !important;
  padding: 0 !important;
} 

/* Fix spacing after using plainlinks class to remove arrow */

#bodyContent .plainlinks a
{ background: none !important;
  padding: 0px !important;
}

/*************************
* Plainlinks tweak - end *
*************************/

/***************************
* Portable Infobox - begin *
***************************/

.portable-infobox
{ max-width: 400px;
  text-align: center;
  margin: 2px;
}

.pi-title
{ text-align: center;
  margin: auto;
}

.portable-infobox-image
{ /* max-width:  400px; */
  width: 400px
  max-height: 400px;
  min-width:  200px;
  min-height: 200px;
  text-align: center;
  margin: auto;
  padding: 2px;
}

.pi-image-thumbnail
{ max-width:  200px;
  max-height: 200px;
  min-width:  50px;
  min-height: 50px;
  text-align: center;
  margin: auto;
}

.pi-caption
{ margin: auto;
  text-align: center;
}

.portable-infobox .pi-data
{ margin: auto;
  text-align: center;
}

/*************************
* Portable Infobox - end *
*************************/

/*******************************
* Quotations templates - begin *
*******************************/

/* Primary settings */
.quotation, .quotation2
{ margin-left: 3em;
  padding: 10px 15px;
  border: solid 1px #ccc; 
  background: #eee; 
  color: black;
}

/* Quotation angle */
.quotation
{ transform: rotate(2deg);
  -moz-transform: rotate(2deg);
  -webkit-transform: rotate(2deg); /* Chrome + Safari */
  -moz-transform: rotate(2deg);    /* Firefox */
  -ms-transform: rotate(2deg);     /* Internet Explorer */
  -khtml-transform: rotate(2deg);  /* Konqueror */
  -o-transform: rotate(2deg);      /* Opera */
}

/* Quotation 2 angle */
.quotation2
{ transform: rotate(-2deg);
  -webkit-transform: rotate(-2deg); /* Chrome + Safari */
  -moz-transform: rotate(-2deg);    /* Firefox */
  -ms-transform: rotate(-2deg);     /* Internet Explorer */
  -khtml-transform: rotate(-2deg);  /* Konqueror */
  -o-transform: rotate(-2deg);      /* Opera */
}

/*****************************
* Quotations templates - end *
*****************************/

/************************
* RecentChanges - begin *
************************/
 
/* Move namespace to the right */
div.namespacesettings
{ float: right;
  clear: none;
  position: relative;
  top: -4em;
  width: 160px;
  border: 1px dotted #666;
  background: #EEE;
  padding: 4px;
  font-size: 90%;
}

/* Byte-change colors */
.mw-plusminus-neg
{ color: red;
}

.mw-plusminus-pos
{ color: green;
}

.mw-plusminus-null
{ color: #777;
}

/** Recent Changes **/
/* "bot" color */
.bot
{ color: red;
}

/* "N" color */
.newpage
{ color: green;
}

/* "m" color */
.minor
{ color: #777;
}

/**********************
* RecentChanges - end *
**********************/

/***********************************************************************
* Redirect tweaks for AllPages (Special Page) & Category lists - begin *
***********************************************************************/
 
.redirect-in-category, .allpagesredirect, .watchlistredirect, 
.redirect-in-category a, .allpagesredirect a, .watchlistredirect a
{ font-style: italic;
  font-size: smaller;
}
 
.redirect-in-category:after, .allpagesredirect:after, .watchlistredirect:after
{ color: #888;
  content: " (redirect)"
}
 
/*********************************************************************
* Redirect tweaks for AllPages (Special Page) & Category lists - end *
*********************************************************************/

/**********************************
* "Show" & "Hide" buttons - begin *
**********************************/

.collapseButton
{ float: right;
  font-weight: normal;
  margin-left: 0.5em;
  text-align: right;
  width: auto;
}

/* Show & hide button balances the v·d·e links from Template:Navbar *
*  so they need to be the same width                                */

.navbox .collapseButton
{ width: 7em;
}
 
/* Styling for JQuery makeCollapsible, matching that of collapseButton */

.mw-collapsible-toggle
{ font-weight: normal;
  /* @noflip */
  text-align: right;
}

.navbox .mw-collapsible-toggle
{ width: 7em;
}

/** Expand / Collapse indicator - begin **/

.expandcollapsetable .indicator
{ cursor: pointer;
  display: inline-block;
  width: 18px;
  height: 16px;
  background: url(https://ikariam.fandom.com/el/wiki/Special:Filepath/Small_control_icons.png) no-repeat scroll transparent;
  position: relative;
  background-position: -54px -1px
}

.expandcollapsetable .indicator:hover
{ background-position: -54px -20px
}

.expandcollapsetable.active .indicator
{ background-position:-72px -1px
}

.expandcollapsetable.active .indicator:hover
{ background-position:-72px -20px
}

/********************************
* "Show" & "Hide" buttons - end *
********************************/

/*************************
* Tabs template  - begin *
*************************/

.activetab                              /* Active tab settings */
{ color: #A4770F !important;
  padding: 3px 1px 1px 1px !important;
  border: 1px #DC8 solid !important;
  border-bottom: 2px solid #DC8 !important;
  border-top-left-radius: 5px;
  -webkit-border-top-left-radius: 5px;  /* Chrome + Safari */
  -moz-border-top-left-radius: 5px;     /* Firefox */
  -ms-border-top-left-radius: 5px;      /* Internet Explorer */
  -khtml-border-top-left-radius: 5px;   /* Konqueror */
  -o-border-top-left-radius: 5px;       /* Opera */
  border-top-right-radius: 5px;  
  -webkit-border-top-right-radius: 5px; /* Chrome + Safari */
  -moz-border-top-right-radius: 5px;    /* Firefox */
  -ms-border-top-right-radius: 5px;     /* Internet Explorer */
  -khtml-border-top-right-radius: 5px;  /* Konqueror */
  -o-border-top-right-radius: 5px;      /* Opera */
  background: #FE9 !important;
}

.inactivetab                            /* Inactive tab settings */
{ color: #A4770F !important;
  border: 1px #DC8 solid !important;
  border-top-left-radius: 5px;
  -webkit-border-top-left-radius: 5px;  /* Chrome + Safari */
  -moz-border-top-left-radius: 5px;     /* Firefox */
  -ms-border-top-left-radius: 5px;      /* Internet Explorer */
  -khtml-border-top-left-radius: 5px;   /* Konqueror */
  -o-border-top-left-radius: 5px;       /* Opera */
  border-top-right-radius: 5px;  
  -webkit-border-top-right-radius: 5px; /* Chrome + Safari */
  -moz-border-top-right-radius: 5px;    /* Firefox */
  -ms-border-top-right-radius: 5px;     /* Internet Explorer */
  -khtml-border-top-right-radius: 5px;  /* Konqueror */
  -o-border-top-right-radius: 5px;      /* Opera */
  background: #DC8 !important;
}

.inactivetab:hover                      /* Inactive tab hover settings */
{ color: #A4770F !important;
  border: 1px #DC8 solid !important;
  background: #FD9 !important;
}

.missingtab                             /* Missing tab settings */
{ color: #000 !important;
  border: 1px #DC8 solid !important;
  border-top-left-radius: 5px;
  -webkit-border-top-left-radius: 5px;  /* Chrome + Safari */
  -moz-border-top-left-radius: 5px;     /* Firefox */
  -ms-border-top-left-radius: 5px;      /* Internet Explorer */
  -khtml-border-top-left-radius: 5px;   /* Konqueror */
  -o-border-top-left-radius: 5px;       /* Opera */
  border-top-right-radius: 5px;  
  -webkit-border-top-right-radius: 5px; /* Chrome + Safari */
  -moz-border-top-right-radius: 5px;    /* Firefox */
  -ms-border-top-right-radius: 5px;     /* Internet Explorer */
  -khtml-border-top-right-radius: 5px;  /* Konqueror */
  -o-border-top-right-radius: 5px;      /* Opera */
  background: #D66 !important;
}

.missingtab:hover                       /* Missing tab Hover settings */
{ color: #000 !important;
  border: 1px #DC8 solid !important;
  background: #F88 !important;
}

/*********************
* Tab template - end *
*********************/

/***********************************
* Tabber (see Help:Tabber) - begin *
***********************************/

.wds-tabber                                                                                 /* tabber wrapper style */
{}

.wds-tabber > .wds-tab__content.wds-is-current                                              /* tabber visible content */
{}

.wds-tabber > .wds-tabs__wrapper > .wds-tabs > .wds-tabs__tab                               /* tabber tabs */
{ color: #A4770F;
  border: solid #DC8 1px;
  background: #FE9;
 }

.wds-tabber > .wds-tabs__wrapper > .wds-tabs > .wds-tabs__tab > .wds-tabs__tab-label        /* tabber tab labels */
{}

.wds-tabber > .wds-tabs__wrapper > .wds-tabs > .wds-tabs__tab:hover                         /* tabber tabs when being hovered */
{ color: #A4770F;
  border: solid #DC8 1px;
  background: #FD9;
}

.wds-tabber > .wds-tabs__wrapper > .wds-tabs > .wds-tabs__tab > .wds-tabs__tab-label:hover  /* tabber tab labels when being hovered */
{}

.wds-tabber > .wds-tabs__wrapper > .wds-tabs > .wds-tabs__tab:active                       /* tabber tabs when being clicked */
{ color: #A4770F;
  background: #FEC;
  border: solid #DC8 1px;
}

.wds-tabber > .wds-tabs__wrapper > .wds-tabs > .wds-tabs__tab > .wds-tabs__tab-label:active /* tabber tab labels when being clicked */
{}

.wds-tabber > .wds-tabs__wrapper > .wds-tabs > .wds-tabs__tab.wds-is-current                 /* selected tabber tab */
{ color: #A4770F;
  background: #EB7;
  border: solid #DC8 1px;
}

.wds-tabber > .wds-tabs__wrapper > .wds-tabs > .wds-tabs__tab.wds-is-current:hover        /* selected tabber tab when being hovered */
{ color: #A4770F;
  border: solid #DC8 1px;
  background: #FD9;
}

.wds-tabber > .wds-tabs__wrapper > .wds-tabs > .wds-tabs__tab.wds-is-current:active       /* selected tabber tab when being clicked */
{}

.wds-tabber > .wds-tabs__wrapper > .wds-tabs__arrow-right,                                 /* tabber arrows */
.wds-tabber > .wds-tabs__wrapper > .wds-tabs__arrow-left
{ color: red;
  background: #CA7;
  border: solid #DC8 1px;
}

/*********************************
* Tabber (see Help:Tabber) - end *
*********************************/

/***************************************
* TabView  (see Help:Tab view) - begin *
***************************************/

.ui-tabs .ui-tabs-nav li a, .yui-navset .yui-nav li, .tabs li a, .wikia-tabs li
{ background: #FEA;
  border-left: 2px #DC8 solid !important;
  border-top: 2px #DC8 solid !important;
  border-right: 2px #DC8 solid !important;
}

.ui-tabs .ui-tabs-nav li a.ui-tabs, .ui-tabs-nav li.ui-tabs-selected a, .tabs .selected a, .wikia-tabs .selected
{ background: #321;
  border-left: 2px #DC8 solid !important;
  border-top: 2px #DC8 solid !important;
  border-right: 2px #DC8 solid !important;
}

.wikia-tabs a, .WikiaSearch input[type="text"], .MyToolsConfiguration .popular-tools-group .popular-toggle
{ color: #FFF;
}

.wikia-tabs .selected a
{ color: #FFF;
}

.ui-tabs .ui-tabs-nav li a
{ margin-right: 2px;
  border-bottom-left-radius: 2px;
  -webkit-border-bottom-left-radius: 2px;  /* Chrome + Safari */
  -moz-border-bottom-left-radius: 2px;     /* Firefox */
  -ms-border-bottom-left-radius: 2px;      /* Internet Explorer */
  -khtml-border-bottom-left-radius: 2px;   /* Konqueror */
  -o-border-bottom-left-radius: 2px;       /* Opera */
  border-bottom-right-radius: 2px;
  -webkit-border-bottom-right-radius: 2px; /* Chrome + Safari */
  -moz-border-bottom-right-radius: 2px;    /* Firefox */
  -ms-border-bottom-right-radius: 2px;     /* Internet Explorer */
  -khtml-border-bottom-right-radius: 2px;  /* Konqueror */
  -o-border-bottom-right-radius: 2px;      /* Opera */
}

.ui-tabs .ui-tabs-nav
{ border-bottom: none;
}

/*************************************
* TabView  (see Help:Tab view) - end *
*************************************/

/********************
* Ol and Ul - begin *
********************/

#content ol, #content ul, #mw_content ol, #mw_content ul
{ margin-bottom: 0.2em;
}

/******************
* Ol and Ul - end *
******************/

/***************************
* Reference styles - begin *
***************************/

/* Make the list of references look smaller */
ol.references
{ font-size: 80%;
}
 
/* Make the list of references in Template:Reflist smaller */
.references-small
{ font-size: 80%;
}

/* Make references 2 columns */
.references-2column
{ font-size: 80%;
  column-count: 2;
  -webkit-column-count: 2; /* Chrome + Safari */
  -moz-column-count: 2;    /* Firefox */
  -ms-column-count: 2;     /* Internet Explorer */
  -khtml-column-count: 2;  /* Konqueror */
  -o-column-count: 2;      /* Opera */
}

/* Highlight clicked reference to help navigation */
ol.references > li:target, sup.reference:target, span.citation:target, cite:target
{ font-size: 120%;
  border: 2px solid #DC8;
}

/* Ensure refs in table headers and the like aren't bold or italic */
sup.reference
{ font-weight: normal;
  font-style: normal;
}

/* <sup> and <sub> Reduced line height and add a Text shadow */
sup, sub
{ line-height: 1em;
  text-shadow: 1px 1px black;
}

/*************************
* Reference styles - end *
*************************/

/*****************************************************************
* Prevent floating boxes from overlapping any category listings, *
* file histories, edit previews, and edit [Show changes] views   *
*****************************************************************/

#mw-subcategories, #mw-pages, #mw-category-media, #filehistory, #wikiPreview, #wikiDiff
{ clear: both;
}

/***********************************
* Site Notification Bubble - begin *  
***********************************/

.WikiaNotification li div, .WikiaNotifications li div
{ background: #FFF;
  border-radius: 4px;
  -webkit-border-radius: 4px; /* Chrome + Safari */
  -moz-border-radius: 4px;    /* Firefox */
  -ms-border-radius: 4px;     /* Internet Explorer */
  -khtml-border-radius: 4px;  /* Konqueror */
  -o-border-radius: 4px;      /* Opera */
  box-shadow: 0 0 5px 0px #fbc;
  -webkit-box-shadow: 0 0 5px 0px #fbc; /* Chrome + Safari */
  -moz-box-shadow: 0 0 5px 0px #fbc;    /* Firefox */
  -ms-box-shadow: 0 0 5px 0px #fbc;     /* Internet Explorer */
  -khtml-box-shadow: 0 0 5px 0px #fbc;  /* Konqueror */
  -o-box-shadow: 0 0 5px 0px #fbc;      /* Opera */
}

/* Wiki Pop-up notification (ex. achievements) */

 .WikiaNotifications .WikiaBadgeNotification p
 { background: #CA7;
   color: #FFF;
 }

/*********************************
* Site Notification Bubble - end *  
*********************************/

/**********************************
* Table Of Contents (TOC) - begin *
**********************************/

/* TOC Title Background and Title Border colors */

.WikiaArticle #toctitle, .WikiaArticle #toctitle h2
{ background: #CA7;
  border: 2px solid #DC8;
}

/* TOC Background and Border colors */

.WikiaArticle .toc
{ background: #FEA;
  border: 2px solid #DC8;
  font-size: 90%;
}

/********************************
* Table Of Contents (TOC) - end *
********************************/

/*********************
 * Tree list - begin *
 ********************/
 
.hiddenlist
{ display: none;
}

.visiblelist
{ display: block;
}

.listexpand
{ text-decoration: none;
}

.listexpand:hover
{ text-decoration: underline;
}

/******************
* Tree list - end *
******************/

/************************************
* UL lists Horizontal Style - begin *
************************************/

.horizontal ul
{ padding: 0;
  margin: 0;
}

.horizontal li
{ padding: 0 0.6em 0 0.4em;
  display: inline;
  border-right: 1px solid;
}

.horizontal li:last-child
{ border-right: none;
  padding-right: 0;
}

/**********************************
* UL lists Horizontal Style - end *
**********************************/

.mw-parser-output, .page-content {
    overflow-x: unset;
}