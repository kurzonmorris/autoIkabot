# FastAPI application structure
# This file is kept for Python package structure
