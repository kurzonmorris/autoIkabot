# FastAPI router will be imported from routes.py
# This file is kept for backward compatibility
