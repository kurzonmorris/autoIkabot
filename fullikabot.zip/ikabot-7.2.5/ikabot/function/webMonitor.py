#! /usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Ikabot Web Monitor
Real-time web-based monitoring interface for Ikabot activities
"""

import json
import os
import sys
import time
from flask import Flask, render_template_string, jsonify, request
from ikabot.helpers.eventLogger import get_events_by_category, get_event_stats, clear_category_events, CATEGORIES
from ikabot.helpers.process import set_child_mode, updateProcessList
from ikabot.helpers.logging import getLogger

logger = getLogger(__name__)

# Load Ikariam icons
try:
    sys.path.insert(0, os.path.dirname(__file__))
    from ikariam_icons import ICONS
except ImportError:
    # Fallback to emoji if icons not available
    ICONS = {
        'wood': '🪵',
        'wine': '🍷',
        'marble': '🏛️',
        'crystal': '💎',
        'sulfur': '🔥',
        'population': '👤'
    }
    logger.warning("Could not load Ikariam icons, using emoji fallback")


app = Flask(__name__)
app.config['TEMPLATES_AUTO_RELOAD'] = True

# Global session object (set when monitor starts)
_session = None


def get_webserver_port(session):
    """
    Try to detect if webServer is running and return its port
    
    Returns
    -------
    port : int or None
        Port number if webServer is running, None otherwise
    """
    try:
        process_list = updateProcessList(session)
        for proc in process_list:
            if proc.get('action') == 'webServer':
                # Try to extract port from process details if available
                # For now, return None - will implement port detection later
                return None
        return None
    except Exception:
        return None


HTML_TEMPLATE = '''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ikabot Monitor - {{ account_name }}</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Arial, sans-serif;
            background: #f5f5f5;
            color: #333;
        }
        
        /* Desktop Layout */
        .container {
            display: grid;
            grid-template-areas:
                "header header"
                "sidebar main";
            grid-template-columns: 350px 1fr;
            grid-template-rows: auto 1fr;
            height: 100vh;
            overflow: hidden;
        }
        
        /* Top Bar */
        .top-bar {
            grid-area: header;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 15px 20px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        
        .account-info {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
        }
        
        .account-name {
            font-size: 18px;
            font-weight: bold;
        }
        
        .controls {
            display: flex;
            gap: 10px;
        }
        
        .btn {
            background: rgba(255,255,255,0.2);
            border: 1px solid rgba(255,255,255,0.3);
            color: white;
            padding: 6px 12px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.2s;
        }
        
        .btn:hover {
            background: rgba(255,255,255,0.3);
        }
        
        .resource-cards {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
        }
        
        .resource-card {
            background: rgba(255,255,255,0.15);
            border-radius: 8px;
            padding: 10px 15px;
            min-width: 120px;
            backdrop-filter: blur(10px);
        }
        
        .resource-icon {
            width: 25px;
            height: 20px;
            display: inline-block;
            vertical-align: middle;
            margin-right: 8px;
        }
        
        .resource-name {
            font-size: 12px;
            opacity: 0.9;
            margin-bottom: 4px;
        }
        
        .resource-amount {
            font-size: 20px;
            font-weight: bold;
        }
        
        .resource-rate {
            font-size: 11px;
            opacity: 0.8;
            margin-top: 2px;
        }
        
        /* Left Sidebar */
        .sidebar {
            grid-area: sidebar;
            background: white;
            border-right: 1px solid #e0e0e0;
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }
        
        .sidebar-header {
            padding: 15px;
            border-bottom: 1px solid #e0e0e0;
        }
        
        .search-box {
            width: 100%;
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
            margin-bottom: 10px;
        }
        
        .filter-controls {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }
        
        .filter-btn {
            padding: 6px 12px;
            border: 1px solid #ddd;
            background: white;
            border-radius: 4px;
            cursor: pointer;
            font-size: 13px;
            transition: all 0.2s;
        }
        
        .filter-btn.active {
            background: #667eea;
            color: white;
            border-color: #667eea;
        }
        
        .events-container {
            flex: 1;
            overflow-y: auto;
            padding: 10px;
        }
        
        .category-section {
            margin-bottom: 20px;
        }
        
        .category-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            background: #f8f9fa;
            border-radius: 6px;
            cursor: pointer;
            user-select: none;
            margin-bottom: 8px;
        }
        
        .category-header:hover {
            background: #e9ecef;
        }
        
        .category-title {
            font-weight: 600;
            font-size: 14px;
        }
        
        .category-controls {
            display: flex;
            gap: 8px;
        }
        
        .icon-btn {
            background: none;
            border: none;
            cursor: pointer;
            font-size: 16px;
            padding: 4px;
            opacity: 0.7;
            transition: opacity 0.2s;
        }
        
        .icon-btn:hover {
            opacity: 1;
        }
        
        .event-item {
            background: white;
            border: 1px solid #e0e0e0;
            border-radius: 6px;
            padding: 12px;
            margin-bottom: 8px;
            transition: all 0.2s;
        }
        
        .event-item:hover {
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        
        .event-item.success {
            border-left: 4px solid #28a745;
        }
        
        .event-item.failure {
            border-left: 4px solid #dc3545;
        }
        
        .event-item.warning {
            border-left: 4px solid #ffc107;
        }
        
        .event-item.info {
            border-left: 4px solid #17a2b8;
        }
        
        .event-header-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 6px;
        }
        
        .event-module {
            background: #e3f2fd;
            padding: 3px 8px;
            border-radius: 3px;
            font-size: 12px;
            color: #1976d2;
            font-weight: 500;
        }
        
        .event-time {
            color: #666;
            font-size: 12px;
        }
        
        .event-message {
            color: #333;
            margin: 6px 0;
            font-size: 14px;
        }
        
        .event-details {
            margin-top: 10px;
            padding: 10px;
            background: #f9f9f9;
            border-radius: 4px;
            font-size: 13px;
            font-family: 'Courier New', monospace;
            display: none;
        }
        
        .event-details.expanded {
            display: block;
        }
        
        .expand-btn {
            color: #667eea;
            cursor: pointer;
            font-size: 12px;
            margin-top: 6px;
            display: inline-block;
        }
        
        .expand-btn:hover {
            text-decoration: underline;
        }
        
        /* Main Content */
        .main-content {
            grid-area: main;
            background: #fafafa;
            overflow: hidden;
            display: flex;
            flex-direction: column;
        }
        
        .content-header {
            padding: 15px 20px;
            background: white;
            border-bottom: 1px solid #e0e0e0;
        }
        
        .iframe-container {
            flex: 1;
            padding: 20px;
            overflow: auto;
        }
        
        .webserver-frame {
            width: 100%;
            height: 100%;
            border: 1px solid #ddd;
            border-radius: 8px;
            background: white;
        }
        
        .no-webserver {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100%;
            color: #999;
        }
        
        /* Mobile Responsive */
        @media (max-width: 768px) {
            .container {
                grid-template-areas:
                    "header"
                    "sidebar"
                    "main";
                grid-template-columns: 1fr;
                grid-template-rows: auto auto 1fr;
            }
            
            .sidebar {
                max-height: 50vh;
                border-right: none;
                border-bottom: 1px solid #e0e0e0;
            }
            
            .resource-cards {
                display: grid;
                grid-template-columns: repeat(2, 1fr);
            }
            
            .main-content {
                display: none; /* Hide webserver on mobile by default */
            }
        }
        
        /* Scrollbar styling */
        ::-webkit-scrollbar {
            width: 8px;
            height: 8px;
        }
        
        ::-webkit-scrollbar-track {
            background: #f1f1f1;
        }
        
        ::-webkit-scrollbar-thumb {
            background: #888;
            border-radius: 4px;
        }
        
        ::-webkit-scrollbar-thumb:hover {
            background: #555;
        }
        
        .hidden {
            display: none !important;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Top Bar -->
        <div class="top-bar">
            <div class="account-info">
                <div>
                    <span class="account-name">👤 {{ account_name }}</span>
                    <span style="opacity: 0.8; margin-left: 10px;">{{ server_name }}</span>
                </div>
                <div class="controls">
                    <button class="btn" onclick="refreshData()">🔄 Refresh</button>
                    <button class="btn" onclick="toggleSettings()">⚙️ Settings</button>
                </div>
            </div>
            
            <div class="resource-cards" id="resourceCards">
                <!-- Resource cards will be inserted here -->
            </div>
        </div>
        
        <!-- Left Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <input type="text" class="search-box" id="searchBox" placeholder="🔍 Search events..." 
                       onkeyup="filterEvents()">
                <div class="filter-controls">
                    <button class="filter-btn active" data-filter="all" onclick="setFilter('all', this)">All</button>
                    <button class="filter-btn" data-filter="success" onclick="setFilter('success', this)">✓ Success</button>
                    <button class="filter-btn" data-filter="failure" onclick="setFilter('failure', this)">✗ Failures</button>
                    <button class="filter-btn" data-filter="warning" onclick="setFilter('warning', this)">⚠ Warnings</button>
                </div>
            </div>
            
            <div class="events-container" id="eventsContainer">
                <!-- Events will be inserted here -->
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="main-content">
            <div class="content-header">
                <h3>Ikariam WebServer</h3>
            </div>
            <div class="iframe-container" id="iframeContainer">
                <div class="no-webserver">
                    <p>🌐 WebServer not detected</p>
                    <p style="font-size: 14px; margin-top: 10px;">Start the webServer module to see Ikariam here</p>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        let currentFilter = 'all';
        let autoRefreshInterval = null;
        let eventsData = {};
        
        // Start auto-refresh (5 seconds)
        startAutoRefresh();
        
        function startAutoRefresh() {
            refreshData();
            autoRefreshInterval = setInterval(refreshData, 5000);
        }
        
        function stopAutoRefresh() {
            if (autoRefreshInterval) {
                clearInterval(autoRefreshInterval);
            }
        }
        
        async function refreshData() {
            try {
                // Fetch events
                const response = await fetch('/api/events');
                const data = await response.json();
                eventsData = data.events;
                
                // Update display
                renderEvents();
                updateResourceCards(data.stats);
                
            } catch (error) {
                console.error('Error fetching data:', error);
            }
        }
        
        function renderEvents() {
            const container = document.getElementById('eventsContainer');
            container.innerHTML = '';
            
            const categories = {{ categories | tojson }};
            
            for (const [categoryKey, categoryName] of Object.entries(categories)) {
                const categoryEvents = eventsData[categoryKey] || [];
                
                if (categoryEvents.length === 0 && currentFilter !== 'all') {
                    continue;
                }
                
                // Create category section
                const section = document.createElement('div');
                section.className = 'category-section';
                section.id = 'category-' + categoryKey;
                
                // Category header
                const header = document.createElement('div');
                header.className = 'category-header';
                header.innerHTML = `
                    <span class="category-title">${getCategoryIcon(categoryKey)} ${categoryName}</span>
                    <div class="category-controls">
                        <button class="icon-btn" onclick="clearCategory('${categoryKey}')" title="Clear">🗑️</button>
                        <button class="icon-btn" onclick="toggleCategory('${categoryKey}')" title="Collapse">▼</button>
                    </div>
                `;
                section.appendChild(header);
                
                // Events
                const eventsDiv = document.createElement('div');
                eventsDiv.id = 'events-' + categoryKey;
                
                const filteredEvents = categoryEvents.filter(event => {
                    if (currentFilter === 'all') return true;
                    return event.event_type === currentFilter;
                });
                
                if (filteredEvents.length === 0) {
                    eventsDiv.innerHTML = '<p style="padding: 10px; color: #999; font-size: 13px;">No recent events</p>';
                } else {
                    filteredEvents.forEach(event => {
                        eventsDiv.appendChild(createEventElement(event));
                    });
                }
                
                section.appendChild(eventsDiv);
                container.appendChild(section);
            }
        }
        
        function createEventElement(event) {
            const div = document.createElement('div');
            div.className = 'event-item ' + event.event_type;
            
            const timeAgo = formatTimeAgo(event.timestamp);
            const icon = getEventIcon(event.event_type);
            
            let detailsHtml = '';
            if (event.details) {
                detailsHtml = `
                    <div class="event-details" id="details-${event.timestamp}">
                        ${JSON.stringify(event.details, null, 2)}
                    </div>
                    <span class="expand-btn" onclick="toggleDetails(${event.timestamp})">▼ Show details</span>
                `;
            }
            
            div.innerHTML = `
                <div class="event-header-row">
                    <span class="event-module">${event.module}</span>
                    <span class="event-time">${timeAgo}</span>
                </div>
                <div class="event-message">${icon} ${event.message}</div>
                ${detailsHtml}
            `;
            
            return div;
        }
        
        function toggleDetails(timestamp) {
            const details = document.getElementById('details-' + timestamp);
            details.classList.toggle('expanded');
        }
        
        function getEventIcon(type) {
            const icons = {
                'success': '✓',
                'failure': '✗',
                'warning': '⚠️',
                'info': 'ℹ️',
                'start': '▶️',
                'end': '⏹️'
            };
            return icons[type] || 'ℹ️';
        }
        
        function getCategoryIcon(category) {
            const icons = {
                'daily': '📅',
                'military': '⚔️',
                'resources': '🚢',
                'alerts': '🚨',
                'construction': '🏗️',
                'custom': '🔧'
            };
            return icons[category] || '📋';
        }
        
        function formatTimeAgo(timestamp) {
            const now = Date.now() / 1000;
            const diff = now - timestamp;
            
            if (diff < 60) return 'just now';
            if (diff < 3600) return Math.floor(diff / 60) + ' min ago';
            if (diff < 86400) return Math.floor(diff / 3600) + 'h ago';
            return Math.floor(diff / 86400) + 'd ago';
        }
        
        function setFilter(filter, btn) {
            currentFilter = filter;
            
            // Update active button
            document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            
            renderEvents();
        }
        
        function filterEvents() {
            const searchTerm = document.getElementById('searchBox').value.toLowerCase();
            // Implement search filtering
            renderEvents();
        }
        
        function toggleCategory(categoryKey) {
            const eventsDiv = document.getElementById('events-' + categoryKey);
            eventsDiv.classList.toggle('hidden');
        }
        
        async function clearCategory(categoryKey) {
            if (!confirm('Clear all events in this category?')) return;
            
            try {
                await fetch('/api/clear_category', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({category: categoryKey})
                });
                refreshData();
            } catch (error) {
                console.error('Error clearing category:', error);
            }
        }
        
        function updateResourceCards(stats) {
            // Placeholder - will be populated with actual resource data
            const cardsHTML = `
                <div class="resource-card">
                    <div class="resource-name">Total Events</div>
                    <div class="resource-amount">${stats.total_events || 0}</div>
                </div>
            `;
            document.getElementById('resourceCards').innerHTML = cardsHTML;
        }
        
        function toggleSettings() {
            alert('Settings panel coming soon!');
        }
    </script>
</body>
</html>
'''


@app.route('/')
def index():
    """Main monitor page"""
    return render_template_string(
        HTML_TEMPLATE,
        account_name=_session.username if _session else 'Unknown',
        server_name=_session.servidor if _session else 'Unknown',
        categories=CATEGORIES
    )


@app.route('/api/events')
def api_events():
    """API endpoint to get events"""
    try:
        events = get_events_by_category(_session, hours_back=24)
        stats = get_event_stats(_session, hours_back=24)
        
        return jsonify({
            'events': events,
            'stats': stats,
            'timestamp': time.time()
        })
    except Exception as e:
        logger.error(f"Error in /api/events: {e}")
        return jsonify({'error': str(e)}), 500


@app.route('/api/clear_category', methods=['POST'])
def api_clear_category():
    """API endpoint to clear a category"""
    try:
        data = request.get_json()
        category = data.get('category')
        
        if clear_category_events(_session, category):
            return jsonify({'success': True})
        else:
            return jsonify({'error': 'Could not clear category'}), 500
    except Exception as e:
        logger.error(f"Error in /api/clear_category: {e}")
        return jsonify({'error': str(e)}), 500


def webMonitor(session, event=None, stdin_fd=None, predetermined_input=None):
    """
    Start the web monitor server
    
    Parameters
    ----------
    session : ikabot.web.session.Session
        Session object
    event : multiprocessing.Event
        Event to signal when ready
    stdin_fd : int
        Standard input file descriptor
    predetermined_input : list
        Predetermined inputs
    """
    global _session
    _session = session
    
    set_child_mode(session)
    
    # Find available port (webServer port + 1, or find next available)
    webserver_port = get_webserver_port(session)
    if webserver_port:
        port = webserver_port + 1
    else:
        port = 42000  # Default starting port
    
    # Try to find an available port
    max_attempts = 100
    for attempt in range(max_attempts):
        try:
            import socket
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.bind(('0.0.0.0', port))
            sock.close()
            break  # Port is available
        except OSError:
            port += 1
    
    print(f"\n{'='*60}")
    print(f"🤖 Ikabot Web Monitor Starting")
    print(f"{'='*60}")
    print(f"\n📊 Access the monitor at:")
    print(f"   http://localhost:{port}")
    print(f"   http://127.0.0.1:{port}")
    
    # Make it accessible from other devices on network
    import socket
    hostname = socket.gethostname()
    try:
        local_ip = socket.gethostbyname(hostname)
        print(f"   http://{local_ip}:{port}")
    except:
        pass
    
    print(f"\n💡 The monitor will auto-refresh every 5 seconds")
    print(f"\n⏹️  Press CTRL+C to stop the server")
    print(f"\n{'='*60}")
    
    # Wait for user confirmation
    if sys.stdin.isatty():
        input("\nPress ENTER to start the web server...")
    
    if event is not None:
        event.set()
    
    print(f"\n🚀 Web Monitor is now running on port {port}")
    print(f"   Open your browser to: http://localhost:{port}\n")
    
    try:
        app.run(host='0.0.0.0', port=port, debug=False, threaded=True)
    except KeyboardInterrupt:
        print("\n\n🛑 Stopping web monitor...")
